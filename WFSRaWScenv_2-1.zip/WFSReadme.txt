Wildfire Studios' Rome at War Mod

 


--------------------------------------------------------------------------------

Installation instructions:

- Requirements

First of all, you need Age of Empires 2: The Conquerors Expansion.

The Rome at War Mod uses MPS 2.0. You can download this tool here MPS Lite 2.0 (used only to install mods) or here Mod Pack Studio 2.0 (used to install and make mods).

No programming skills and stuff like that are required because the modpack is autoexecutable, but you need to move certain included files to their specific folder.

 

- Installing the mod

The Rome at War Mod is in a zip file (where this document is) so unzip the included *.akx file to anywhere you want and then, double click the file to install and run Rome at War.

Once you double clicked, a small window will appear, showing you the text "Wait while MPS install this modpack". 

Another small window will appear, with two icons and the text "This modpack can be used with multiple versions of AOK. Please select the version to run now". Select "The Conquerors" and then you will run the game with the mod installed.

When you get tired of playing and want to leave, but you want all the original game stuff restored, just leave the game as you normally do it. MPS always uninstalls an installed modpack after leaving the game. Then you will have to reinstall Rome at War in the next time you want to play it.

But if you loved the mod and wanted it always installed, you can do it. You have to double click the akx file, run AOK and once you are in the game, with the mod running, press ALT + TAB to minimize the game, then CTRL + ALT + DEL once you are in Windows. In the "End Task" window, select "Mod Pack Studio" and you will end the program, but you will leave all the mod installed. To restore the original AOK stuff you will need to reinstall the game.

 

- Installing the mod complements

Now, we will get your attention to the other files, apart of the executable akx mod. 

There are some other files that MUST go to their specific folder in the "Age of Empires 2" directory installation. These files are:
1. Two sound files, Aztecs.mp3 and Mayans.mp3. They MUST be in Age of Empires 2/Sound/Stream.
2. Two *.txt files, Romans.txt and Greeks.txt. They MUST be in Age of Empires II/History.
3. Two *.dll files, Language.dll and Language_x1.dll. They MUST be in Age of Empires II (main directory)
4. AI and per files go in Age of Empires II/AI
5. Example CPX file goes in Age of Empires II/Scnenario
 

- Final thoughts

Well, we have told you all you need to install and play the WFS' Rome at War modpack. Now we can only tell you one more thing:

ENJOY!!!!!!

If you still have some questions visit WFS Forums

http://forums.heavengames.com/wfs/cgi-bin/Ultimate.cgi

 


--------------------------------------------------------------------------------

Credits:

...: Courtesy of WildFire Studios :...

Wijitmaker - Project leader

and thanks to all the members of WFS, beta testers, and many, many others:

ES - for making such a wonderful game
Sierra Design and Data Becker - for using some of their great graphics
AOKH - for hosting it the mod, and having such a great modforum
SCNPunk - for hosting our team WildFire Studios
Angel Zen - for hooking our ftp up, and making our forums
Topknot - for his legion, and language dll help
SUD_Commander - for all the sounds
Dire_Wolf - for the Parthenon
Aznknightmare - for the trebuchet
Habbit Bundy - for the Auxila
Topknot, BullsWool - for their expertice, and advice
The other mod team, and AOKH modding community - For getting some ideas from them, and learning the skills of modding
Enrique Orduno - for cracking the TWALL
Ingrownlip - for the flash movie
Derfel Cadarn, Cian Mcguire, Topknot, RomeIsTheBest, Revned, SUD_Commander, AlejandroGonzo, BBT, and The_Piemaster - for reviewing the mod

and more and more people that helped with the making off of this mod!!

